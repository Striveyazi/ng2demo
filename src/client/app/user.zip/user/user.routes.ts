import {UserComponent} from './index';
import { Route } from '@angular/router';
export const UserRoutes:Route[]=[
    {
        path:'userInfo',
        component:UserComponent
    }
];